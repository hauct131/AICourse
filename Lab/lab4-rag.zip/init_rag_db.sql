-- ============================================================
--  RAG Database Schema — for the rag-ai-local Markdown corpus
--  (QandA + functionality-docs from Module 3)
--  Database: ai_db   ·   Embedding: nomic-embed-text (768-dim)
-- ------------------------------------------------------------
--  Progressive design — one schema, three labs:
--    [Lab 1 · basic]   fixed-token body chunks + vector search
--    [Lab 2 · metadata] parse frontmatter -> fill doc metadata,
--                       description, summary, per-chunk metadata
--    [Lab 3 · hybrid]  full-text (content_tsv) + Elasticsearch
--  Columns/indexes for later labs already exist but stay empty
--  until that lab uses them. Re-applied idempotently by migrations.py.
-- ============================================================

CREATE EXTENSION IF NOT EXISTS vector;

-- ============================================================
-- 1. DOCUMENTS — one row per .md file in input/
-- ============================================================
CREATE TABLE IF NOT EXISTS rag_documents (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source_path   TEXT NOT NULL UNIQUE,       -- e.g. rag-ai-local/QandA/07042026_Agentic_Crawler_Replay_Trap.md
    raw_content   TEXT,                        -- [Lab 1] full file text (as loaded)

    -- ---- filled in [Lab 2 · metadata] from YAML frontmatter + TL;DR ----
    doc_type      VARCHAR(30),                 -- 'qanda' | 'functionality'
    title         TEXT,
    doc_date      DATE,
    area          VARCHAR(100),                -- feature/area slug (facet pre-filter)
    status        VARCHAR(40),                 -- investigation | in-progress | implementation-complete | superseded
    tags          TEXT[],                      -- faceted pre-filter
    description   TEXT,                         -- short one-line description
    summary       TEXT,                         -- TL;DR (What / Why / Where / Impact)
    metadata      JSONB,                        -- any extra frontmatter, unmodelled

    created_at    TIMESTAMP DEFAULT NOW(),
    updated_at    TIMESTAMP DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_rag_documents_type   ON rag_documents(doc_type);
CREATE INDEX IF NOT EXISTS idx_rag_documents_area   ON rag_documents(area);
CREATE INDEX IF NOT EXISTS idx_rag_documents_status ON rag_documents(status);
CREATE INDEX IF NOT EXISTS idx_rag_documents_meta   ON rag_documents USING GIN(metadata);

COMMENT ON TABLE  rag_documents           IS 'One row per source .md file (QandA / functionality-doc)';
COMMENT ON COLUMN rag_documents.summary   IS 'TL;DR block (What/Why/Where/Impact) — filled in the metadata lab';
COMMENT ON COLUMN rag_documents.area      IS 'Feature/area slug used for metadata pre-filter';

-- ============================================================
-- 2. CHUNKS — many rows per document (fixed-token body chunks)
-- ============================================================
CREATE TABLE IF NOT EXISTS rag_chunks (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    document_id   UUID NOT NULL REFERENCES rag_documents(id) ON DELETE CASCADE,
    chunk_index   INT  NOT NULL,               -- [Lab 1] order within the document (0,1,2,...)
    content       TEXT NOT NULL,               -- [Lab 1] the fixed-token body chunk
    token_count   INT,                         -- [Lab 1] tokens in this chunk

    metadata      JSONB,                        -- [Lab 2] per-chunk metadata (doc fields + section heading)
    content_tsv   tsvector,                     -- [Lab 3] full-text vector (hybrid / BM25)

    created_at    TIMESTAMP DEFAULT NOW(),
    UNIQUE (document_id, chunk_index)
);
CREATE INDEX IF NOT EXISTS idx_rag_chunks_document ON rag_chunks(document_id);
CREATE INDEX IF NOT EXISTS idx_rag_chunks_meta     ON rag_chunks USING GIN(metadata);
-- [Lab 3] full-text index for hybrid search
CREATE INDEX IF NOT EXISTS idx_rag_chunks_tsv      ON rag_chunks USING GIN(content_tsv);

COMMENT ON TABLE  rag_chunks             IS 'Fixed-token body chunks of a document (basic RAG unit)';
COMMENT ON COLUMN rag_chunks.content_tsv IS 'Full-text search vector — used only in the hybrid-search lab';

-- ============================================================
-- 3. EMBEDDINGS — one vector per chunk (1:1)
--    Split from chunks so you can re-embed with a new model
--    without touching the chunk text.
-- ============================================================
CREATE TABLE IF NOT EXISTS rag_embeddings (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    chunk_id      UUID NOT NULL REFERENCES rag_chunks(id) ON DELETE CASCADE,
    embedding     vector({{EMBEDDING_DIM}}) NOT NULL,   -- 768 = nomic-embed-text (local)
    model         VARCHAR(80),                          -- e.g. 'nomic-embed-text'
    indexed_at    TIMESTAMP DEFAULT NOW(),
    UNIQUE (chunk_id)
);
CREATE INDEX IF NOT EXISTS idx_rag_embeddings_chunk ON rag_embeddings(chunk_id);

COMMENT ON TABLE rag_embeddings IS 'One embedding vector per chunk (nomic-embed-text, 768-dim)';

-- Vector similarity index — create AFTER you have rows (IVFFlat needs data to train).
-- Uncomment and run once after your first index, then it speeds up top-k search:
-- CREATE INDEX IF NOT EXISTS idx_rag_embeddings_vector ON rag_embeddings
--     USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100);

-- ============================================================
-- 4. Triggers — auto updated_at + auto full-text vector
-- ============================================================
CREATE OR REPLACE FUNCTION rag_touch_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_rag_documents_updated ON rag_documents;
CREATE TRIGGER trg_rag_documents_updated
    BEFORE UPDATE ON rag_documents
    FOR EACH ROW EXECUTE FUNCTION rag_touch_updated_at();

-- [Lab 3] auto-fill content_tsv from the chunk content (English config).
CREATE OR REPLACE FUNCTION rag_chunk_tsv()
RETURNS TRIGGER AS $$
BEGIN
    NEW.content_tsv = to_tsvector('english', COALESCE(NEW.content, ''));
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_rag_chunks_tsv ON rag_chunks;
CREATE TRIGGER trg_rag_chunks_tsv
    BEFORE INSERT OR UPDATE ON rag_chunks
    FOR EACH ROW EXECUTE FUNCTION rag_chunk_tsv();

-- ============================================================
-- Grants: the connecting app user owns these tables, so no GRANT
-- is needed. If you run the app under a SEPARATE role, uncomment:
-- GRANT ALL PRIVILEGES ON ALL TABLES    IN SCHEMA public TO ai_user;
-- GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO ai_user;
-- ============================================================
-- END OF SCHEMA
-- ============================================================
