"""
Idempotent database migrations for the RAG lab.

Applies sql/init_rag_db.sql on startup. Improvement over a name-only tracker:
it tracks the SHA-256 of the SQL file, so whenever you EDIT the SQL, the hash
changes and the migration re-applies automatically. The schema is written to be
idempotent (CREATE ... IF NOT EXISTS, CREATE OR REPLACE, DROP TRIGGER IF EXISTS),
so re-applying is always safe.

Connection + embedding dimension come from environment variables (docker-compose
injects them). Run on app startup, or manually:  python migrations.py
"""
import hashlib
import os

import psycopg  # psycopg 3

SQL_FILE = os.path.join(os.path.dirname(__file__), "sql", "init_rag_db.sql")
EMBEDDING_DIM = os.environ.get("EMBEDDING_DIM", "768")  # nomic-embed-text = 768


def _conn():
    return psycopg.connect(
        host=os.environ["POSTGRES_HOST"],
        port=os.environ["POSTGRES_HOST_PORT"],
        user=os.environ["POSTGRES_USER"],
        password=os.environ["POSTGRES_PASSWORD"],
        dbname=os.environ["POSTGRES_DB"],
    )


def _ensure_tracking_table(cur):
    cur.execute("""
        CREATE TABLE IF NOT EXISTS schema_migrations (
            name        TEXT PRIMARY KEY,
            file_hash   TEXT NOT NULL,
            applied_at  TIMESTAMP DEFAULT NOW()
        )
    """)


def run_migrations():
    with open(SQL_FILE, "r", encoding="utf-8") as f:
        sql = f.read()

    # Substitute the embedding dimension placeholder (768 local / 1024 Bedrock, etc.)
    sql = sql.replace("{{EMBEDDING_DIM}}", str(EMBEDDING_DIM))
    file_hash = hashlib.sha256(sql.encode("utf-8")).hexdigest()
    name = os.path.basename(SQL_FILE)

    with _conn() as conn:
        with conn.cursor() as cur:
            _ensure_tracking_table(cur)
            cur.execute("SELECT file_hash FROM schema_migrations WHERE name = %s", (name,))
            row = cur.fetchone()
            if row and row[0] == file_hash:
                print(f"[migrations] {name} unchanged — skip")
                return

            print(f"[migrations] applying {name} (dim={EMBEDDING_DIM}) ...")
            cur.execute(sql)  # the whole idempotent schema
            cur.execute(
                """INSERT INTO schema_migrations (name, file_hash) VALUES (%s, %s)
                   ON CONFLICT (name) DO UPDATE SET file_hash = EXCLUDED.file_hash,
                                                    applied_at = NOW()""",
                (name, file_hash),
            )
        conn.commit()
    print(f"[migrations] {name} applied ✔")


if __name__ == "__main__":
    run_migrations()
